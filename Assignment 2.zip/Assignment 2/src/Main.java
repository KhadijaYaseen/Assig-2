import org.w3c.dom.ls.LSOutput;

import java.awt.*;
import java.sql.SQLOutput;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;
import java.util.regex.Pattern;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.time.format.DateTimeFormatter;
import java.time.LocalDate;
//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        //task 1
//        Scanner input = new Scanner(System.in);
//        System.out.println("Enter String To Check: ");
//        String str = input.nextLine();
//        int strlen = str.length();
//        boolean flag = true;
//        for (int i = 0; i < strlen / 2; i++) {
//            if (str.charAt(i) != str.charAt(strlen - i - 1)) {
//                flag = false;
//                break;
//            }
//        }
//        String result = (flag == true) ? "is Palindrom" : "not Palindrom";
//        System.out.println(result);

        //Task 2
//        Scanner input = new Scanner(System.in);
//        System.out.println("Enter String To Check: ");
//        String str = input.nextLine();
//        Pattern pattern= Pattern.compile("([a-za-z]+\\d|[a-za-z]|.[a-za-z]+)@gmail.com");
//        Matcher matcher=pattern.matcher(str);
//        boolean b= matcher.matches();
//        if(b){
//            System.out.println("Valid");
//        }
//        else{
//            System.out.println("Invalid");
//        }

        //task 3
//        LocalDate today =LocalDate.now();
//        String newDate= today.format(DateTimeFormatter.ofPattern("dd-MM-YYYY"));
//        System.out.println("Before: "+ today);
//        System.out.println("After: "+ newDate);
        //Task4
//        Scanner input = new Scanner(System.in);
//        System.out.println("Enter Date: ");
//        String str= input.nextLine();//yyyy-mm-dd
//        LocalDate date =LocalDate.parse(str);
//        date = date.plusDays(30);
//        System.out.println(date.format(DateTimeFormatter.ofPattern("dd-MM-yyyy")));
        //Task 5
//        Scanner input = new Scanner(System.in);
//        System.out.println("Enter a Number:");
//        String str = input.nextLine();
//        int nInt = Integer.parseInt(str);//convert string to integer
//        String[] rnChars = {"M", "CM", "D", "C", "XC", "L", "X", "IX", "V", "I"};
//        int[] rnVals = {1000, 900, 500, 100, 90, 50, 10, 9, 5, 1};
//        String retVal = "";
//        for (int i = 0; i < rnVals.length; i++) {
//            int num = nInt / rnVals[i];
//            if (num == 0)
//                continue;
//            retVal += (num == 4 && i > 0) ? rnChars[i] + rnChars[i - 1] : rnChars[i];
//            nInt %= rnVals[i];
//        }
//        System.out.println(retVal);


        //Task6
//    Scanner input= new Scanner(System.in);
//        System.out.println("Enter  braces to check: ");
//        String str = input.nextLine();
//      if ( Pattern.compile("\\(\\)|\\{\\}|\\[\\]|\\(\\)\\[\\]\\{\\}|\\[\\]\\(\\)\\{\\}|\\{\\}\\(\\)\\[\\]").matcher(str).matches()) {
//          System.out.println("Valid");
//      }
//      else System.out.println("Invalid");


//     Task 7
//        Scanner input= new Scanner(System.in);
//
//        String [] strArry= {"flower","flow","flight"};
//        if (strArry.length==0)
//            System.out.println("String is empty.");
//        else if (strArry.length==1) {
//            System.out.println(strArry[0]);
//        }
//        else
//           String firstStr = strArry[0];
//        for(int i=1;i<strArry.length;i++){
//           String   currstr =strArry[i];
//          int  j=0;
//          while (i<currstr.length()&&j<currstr.length()&&
//         currstr.charAt(j)==firstStr.chartAt(i)){
//              j++;
//          }
//          if(j==0){
//              System.out.println(" This is not matched.");
//          break;
    }
//          firstStr= currstr.substring(0,j);
//        }
//        System.out.println(firstStr);


    //Task 8




//        public static void main(String[] args) {
//            Scanner input = new Scanner(System.in);
//            System.out.println("Enter new string: ");
//            String str = input.nextLine();
//            String newStr = "";
//            char[] arr = str.toCharArray();
//
//            for (int i = 0; i < arr.length; i++) {
//                boolean isUnique = true; // Move the declaration inside the outer loop
//
//                for (int j = 0; j < i; j++) { // Check for uniqueness
//                    if (arr[i] == arr[j]) {
//                        isUnique = false; // Mark as not unique
//                        break; // Exit inner loop
//                    }
//                }
//
//                if (isUnique) { // Add to newStr if unique
//                    newStr += arr[i];
//                }
//            }
//
//            System.out.println(newStr);
//        }
//    }



